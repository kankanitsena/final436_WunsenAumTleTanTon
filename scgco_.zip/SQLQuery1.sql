﻿CREATE TABLE Emails (
    EmailID INT PRIMARY KEY IDENTITY(1,1),
    EmailSubject NVARCHAR(255),
    EmailMessage NVARCHAR(MAX),
    EmailDate DATETIME,
    EmailIsRead BIT,
    EmailSender NVARCHAR(255),
    EmailReceiver NVARCHAR(255)
);
