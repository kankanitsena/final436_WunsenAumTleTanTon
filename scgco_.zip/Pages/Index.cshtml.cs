﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;
using System.Collections.Generic;
using System;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace FinalProject.Pages
{
    public class IndexModel : PageModel
    {
        private readonly string _connectionString;
        private readonly ILogger<IndexModel> _logger;

        public List<EmailInfo> listEmails = new List<EmailInfo>();

        public IndexModel(ILogger<IndexModel> logger, IConfiguration configuration)
        {
            _logger = logger;
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public void OnGet()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    connection.Open();

                    string username = User.Identity?.Name ?? "";  // ชื่อผู้ใช้ที่ล็อกอิน

                    // ปรับ query ด้วย SQL Parameter เพื่อป้องกัน SQL Injection
                    string sql = "SELECT * FROM emails WHERE EmailReceiver = @EmailReceiver";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@EmailReceiver", username);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                EmailInfo emailInfo = new EmailInfo
                                {
                                    EmailID = reader.GetInt32(0),
                                    EmailSubject = reader.GetString(1),
                                    EmailMessage = reader.GetString(2),
                                    EmailDate = reader.GetDateTime(3),
                                    EmailIsRead = reader.GetBoolean(4),
                                    EmailSender = reader.GetString(5),
                                    EmailReceiver = reader.GetString(6),
                                    EmailAttachment = reader["EmailAttachment"]?.ToString()
                                };

                                listEmails.Add(emailInfo);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading emails");
            }
        }
    }

    public class EmailInfo
    {
        public int EmailID { get; set; }
        public string? EmailSubject { get; set; }
        public string? EmailMessage { get; set; }
        public DateTime EmailDate { get; set; }
        public bool EmailIsRead { get; set; }
        public string? EmailSender { get; set; }
        public string? EmailReceiver { get; set; }
        public string EmailAttachment { get; set; }
    }
}
