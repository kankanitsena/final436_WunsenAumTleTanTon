using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;
using System.IO;
using System.Threading.Tasks;

namespace FinalProject.Pages
{
    public class ComposeMailModel : PageModel
    {
        private readonly string _connectionString;

        public ComposeMailModel(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        [BindProperty]
        public string? Subject { get; set; }

        [BindProperty]
        public string? Body { get; set; }

        [BindProperty]
        public string? Receiver { get; set; }

        [BindProperty]
        public IFormFile Attachment { get; set; }

        public async Task<IActionResult> OnPostAsync()
        {
            // Validate required fields
            if (string.IsNullOrWhiteSpace(Subject) || string.IsNullOrWhiteSpace(Body) || string.IsNullOrWhiteSpace(Receiver))
            {
                ModelState.AddModelError(string.Empty, "All fields are required.");
                return Page();
            }

            // Get the sender
            string Sender = User.Identity?.Name ?? "Unknown Sender";

            try
            {
                string filePath = null;

                if (Attachment != null)
                {
                    // Save the file locally or to a cloud storage
                    string uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads");
                    Directory.CreateDirectory(uploadsFolder);

                    filePath = Path.Combine(uploadsFolder, Attachment.FileName);
                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        await Attachment.CopyToAsync(fileStream);
                    }
                }
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    await connection.OpenAsync();
                    string query = @"
                        INSERT INTO Emails (EmailSubject, EmailMessage, EmailDate, EmailIsRead, EmailSender, EmailReceiver, EmailAttachment) 
                        VALUES (@EmailSubject, @EmailMessage, @EmailDate, @EmailIsRead, @EmailSender, @EmailReceiver, @EmailAttachment)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@EmailSubject", Subject.Trim());
                        command.Parameters.AddWithValue("@EmailMessage", Body.Trim());
                        command.Parameters.AddWithValue("@EmailDate", DateTime.Now);
                        command.Parameters.AddWithValue("@EmailIsRead", false); // Mark as unread
                        command.Parameters.AddWithValue("@EmailSender", Sender);
                        command.Parameters.AddWithValue("@EmailReceiver", Receiver.Trim());
                        command.Parameters.AddWithValue("@EmailAttachment", filePath ?? string.Empty);

                        await command.ExecuteNonQueryAsync();
                    }
                }
            }
            catch (Exception ex)
            {
                // Log error (optional)
                Console.WriteLine(ex.Message);
                ModelState.AddModelError(string.Empty, "An error occurred while sending the email.");
                return Page();
            }

            // Redirect back to index page after successful submission
            return RedirectToPage("/Index");
        }
    }
}
