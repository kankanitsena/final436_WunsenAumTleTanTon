﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;

namespace FinalProject.Controllers
{
    public class EmailController : Controller
    {
        private readonly string _connectionString;

        public EmailController(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        // Action สำหรับลบอีเมล
        public async Task<IActionResult> DeleteEmail(int emailid)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();

                // Query สำหรับลบอีเมลจากฐานข้อมูล
                string query = "DELETE FROM Emails WHERE EmailId = @EmailId";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@EmailId", emailid);

                    // ลบข้อมูลอีเมล
                    await command.ExecuteNonQueryAsync();
                }
            }

            // หลังจากลบเสร็จแล้วกลับไปที่หน้า Index หรือหน้าอื่นๆ
            return RedirectToAction("Index", "Email");
        }
    }
}
