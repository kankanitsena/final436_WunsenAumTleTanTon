using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Primitives;
using System.Threading.Tasks;

namespace FinalProject.Pages
{
    public class DeleteEmailModel : PageModel
    {
        private readonly string _connectionString;

        public DeleteEmailModel(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        // Handle GET request and delete the email
        public async Task<IActionResult> OnGetAsync()
        {
            // �Ѻ��� emailid �ҡ query string
            Request.Query.TryGetValue("emailid", out StringValues emailId);
            if (emailId.Count == 0)
            {
                // ���������Ѻ emailid �ҡ query string
                return NotFound();
            }

            int id;
            if (!int.TryParse(emailId.ToString(), out id))
            {
                return BadRequest("Invalid email ID.");
            }

            try
            {
                // ź����Ũҡ�ҹ������
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    await connection.OpenAsync();
                    string query = "DELETE FROM Emails WHERE EmailID = @EmailId";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@EmailId", id);
                        await command.ExecuteNonQueryAsync();
                    }
                }

                // ��ѧ�ҡź������������� ��Ѻ价��˹�� Index
                return RedirectToPage("Index");
            }
            catch (Exception ex)
            {
                // �ҡ�բ�ͼԴ��Ҵ ����ʴ���ͼԴ��Ҵ
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }
}
