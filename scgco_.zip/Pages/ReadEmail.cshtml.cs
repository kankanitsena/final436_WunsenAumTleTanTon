using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;

namespace FinalProject.Pages
{
    public class ReadEmailModel : PageModel
    {
        private readonly string _connectionString;

        public EmailInfo? emailInfo { get; set; }

        public ReadEmailModel(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public IActionResult OnGet(int? emailid)
        {
            if (emailid == null || emailid <= 0)
            {
                return RedirectToPage("/Error");
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    connection.Open();

                    // Fetch email details
                    string query = "SELECT EmailId, EmailSubject, EmailMessage, EmailDate, EmailSender, EmailReceiver , EmailAttachment FROM Emails WHERE EmailId = @EmailId";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@EmailId", emailid);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                emailInfo = new EmailInfo
                                {
                                    EmailID = reader.GetInt32(0),
                                    EmailSubject = reader.GetString(1),
                                    EmailMessage = reader.GetString(2),
                                    EmailDate = reader.GetDateTime(3),
                                    EmailSender = reader.GetString(4),
                                    EmailReceiver = reader.GetString(5),
                                    EmailAttachment = reader["EmailAttachment"]?.ToString()
                                };
                            }
                            else
                            {
                                return RedirectToPage("/Error");
                            }
                        }
                    }

                    // Mark email as read
                    string updateQuery = "UPDATE Emails SET EmailIsRead = 1 WHERE EmailId = @EmailId";
                    using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                    {
                        updateCommand.Parameters.AddWithValue("@EmailId", emailid);
                        updateCommand.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                return RedirectToPage("/Error");
            }

            return Page();
        }
        public IActionResult OnGetDownload(int emailId)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    connection.Open();

                    string query = "SELECT EmailAttachment FROM Emails WHERE EmailId = @EMailId";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@EMailId", emailId);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                string filePath = reader["EmailAttachment"]?.ToString();
                                if (!string.IsNullOrEmpty(filePath) && System.IO.File.Exists(filePath))
                                {
                                    byte[] fileBytes = System.IO.File.ReadAllBytes(filePath);
                                    string fileName = Path.GetFileName(filePath);

                                    return File(fileBytes, "application/octet-stream", fileName);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }

            return RedirectToPage("/Error");
        }
    }
}