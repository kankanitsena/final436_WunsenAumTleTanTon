﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

function openEmailDetails(emailId) {
    fetch(`/ReadEmail?emailid=${emailId}`)
        .then(response => response.json())
        .then(data => {
            // Update Modal Content
            document.getElementById('modalEmailSubject').innerText = data.emailSubject;
            document.getElementById('modalEmailSender').innerText = data.emailSender;
            document.getElementById('modalEmailReceiver').innerText = data.emailReceiver;
            document.getElementById('modalEmailDate').innerText = new Date(data.emailDate).toLocaleString();
            document.getElementById('modalEmailBody').innerText = data.emailMessage;

            // Update Reply Link
            document.getElementById('modalReplyLink').href = `/ComposeMail?Receiver=${data.emailSender}&Subject=Re: ${data.emailSubject}`;

            // Show Modal
            new bootstrap.Modal(document.getElementById('emailModal')).show();
        })
        .catch(error => {
            console.error('Error fetching email details:', error);
            alert('Failed to load email details.');
        });
}

